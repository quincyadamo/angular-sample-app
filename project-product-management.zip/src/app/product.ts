export class Product {
  title: string;
  price: string;
  imageUrl: string;
  id: number;
  constructor(){

  }
}